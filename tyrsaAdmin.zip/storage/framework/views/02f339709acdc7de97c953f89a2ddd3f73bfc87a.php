<div class="preloader flex-column justify-content-center align-items-center">

    
    <img src="<?php echo e(asset(config('adminlte.preloader.img.path', 'vendor/adminlte/dist/img/TyrsaLogo.png'))); ?>"
         class="<?php echo e(config('adminlte.preloader.img.effect', 'animation__shake')); ?>"
         alt="<?php echo e(config('adminlte.preloader.img.alt', 'TYRSA Preloader Image')); ?>"
         width="<?php echo e(config('adminlte.preloader.img.width', 289)); ?>"
         height="<?php echo e(config('adminlte.preloader.img.height', 150)); ?>">

</div>
<?php /**PATH C:\xampp\htdocs\admintyrsa2\tyrsaAdmin\vendor\jeroennoten\laravel-adminlte\src/../resources/views/partials/common/preloader.blade.php ENDPATH**/ ?>