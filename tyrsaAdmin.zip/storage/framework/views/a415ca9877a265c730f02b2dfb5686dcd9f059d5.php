

<?php $__env->startSection('title', 'PEDIDO INTERNO'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1 class="font-bold"><i class="fa-solid fa-credit-card"></i>&nbsp; CONDICIONES DE PAGO</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-flex m-1 bg-gray-300 shadow-lg rounded-lg">

        <div class="row p-3 m-2 rounded-lg shadow-xl bg-white">
            <div class="row p-4">
                <div class="col-sm-12 text-center font-bold text-sm">
                <table>
                        <tr>
                            <td rowspan="4">
                               <img src="<?php echo e(asset('img/logo/logo.svg')); ?>" alt="TYRSA">
                            </td>
                        </tr>
                        <tr>
                            <td class="text-lg" style="color: red"><?php echo e($CompanyProfiles->company); ?></td>
                        </tr>
                        <tr>
                            <td><?php echo e($CompanyProfiles->motto); ?></td>
                        </tr>
                        <tr class="text-xs">
                            <td>
                                <br>
                                Domicilio Fiscal:<br>
                                <?php echo e($CompanyProfiles->street.' '.$CompanyProfiles->outdoor.' '.$CompanyProfiles->intdoor.' '.$CompanyProfiles->suburb.' '.$CompanyProfiles->city.' '.$CompanyProfiles->state.' '.$CompanyProfiles->zip_code); ?><br>
                                R.F.C: <?php echo e($CompanyProfiles->rfc); ?> &nbsp; Tels: 01-52 <?php echo e($CompanyProfiles->telephone.', '.$CompanyProfiles->telephone2); ?> &nbsp; E-mail: <?php echo e($CompanyProfiles->email); ?> &nbsp; Web: <?php echo e($CompanyProfiles->website); ?>

                            </td>
                        </tr>
                    </table>
                    <br><br>
                    <table class="table">
  <thead>
    <tr>
      <th scope="col">RESUMEN DEL PEDIDO INTERNO (P.I.) NUMERO</th>
      <td ><?php echo e($InternalOrders->invoice); ?></td>
      
    </tr>
  </thead>
  <tbody>
    <tr>
      <th scope="row">Moneda</th>
      <td><?php echo e($Coins->code); ?></td>
      
    </tr>
  </tbody>
  
</table>
                    <br><br>

<table>
  <tbody>
    <tr>
     <td scope="col">Cliente:</td>
     <td><?php echo e($Customers->customer); ?></td>
    </tr>
    <tr   >
     <td scope="col">Saldo deudor     (-):</td>
     <td style="color:#ff0000"> <?php echo e($Coins -> symbol); ?> <?php echo e(number_format( $Subtotal * 1.16 - $abonos->sum('amount'))); ?></td>
    </tr>
    <tr style="background-color: #4dff88">
     <td scope="col">Abonos Recibidos (+):</td>
     <td><?php echo e($abonos->count()); ?></td>
    </tr>
  </tbody>
</table>


<br><br>
<h1 ><span class="badge badge-secondary" style="font-size : 19px; align-self: start;">Derechos Adquiridos PI: <?php echo e($InternalOrders->invoice); ?> <br>Convenio Inicial </span></h1>


<table class="table table-striped">
  <thead class="thead">
    <tr>
      <th scope="col">Entregable</th>
      <th > % Negociado</th>
      <th scope="col">Monto sin IVA</th>
      <th scope="col">IVA</th>
      <th scope="col">TOTAL</th>
      <th scope="col">Promesa de Pago </th>
      <th scope="col"># Dias </th>
      <th scope="col"># Semanas </th>

    </tr>
  </thead>
  <tbody>
  <?php $__currentLoopData = $hpayments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


  <?php
{{$datetime1 = new DateTime($row->date);
  $datetime2 = new DateTime("2022-1-1");
  $dias = $datetime1->diff($datetime2)->format('%a');}}
?>
                            <tr class="text-center">
                                <td>  <?php echo e($row->concept); ?></td>
                                <td><?php echo e($row->percentage); ?> %</td>
                                <td><?php echo e($Coins -> symbol); ?> <?php echo e(number_format( $row->percentage * $Subtotal * 0.01)); ?></td>
                                <td><?php echo e($Coins -> symbol); ?> <?php echo e(number_format( $row->percentage * $Subtotal *0.0016)); ?></td>
                                <td><?php echo e($Coins -> symbol); ?> <?php echo e(number_format( $row->amount )); ?></td>
                                <td><?php echo e($row->date); ?></td>
                                <td><?php echo e($dias); ?></td>
                                <td><?php echo e((int)($dias / 7)); ?></td>
                      
                                
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <tr >
                            <td> </td>
    <th scope="row">TOTAL: </th>
      
      <td style="background-color:#A6ADBC"><?php echo e($Coins -> symbol); ?> <?php echo e(number_format($Subtotal)); ?></td>
      <td style="background-color:#A6ADBC"> <?php echo e($Coins -> symbol); ?> <?php echo e(number_format($Subtotal*0.16)); ?></td>
      <td style="background-color:#A6ADBC"> <?php echo e($Coins -> symbol); ?> <?php echo e(number_format($Subtotal*1.16)); ?></td>
    </tr>
   
  </tbody>
</table>
<br><br>


<h1 ><span class="badge badge-secondary" style="font-size : 19px; align-self: start;">Derechos adquiridos PI: <?php echo e($InternalOrders->invoice); ?>  <br>Modificado </span></h1>
<form action="<?php echo e(route('internal_orders.pay_conditions')); ?>" method="POST" enctype="multipart/form-data">
<?php echo csrf_field(); ?>
<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.input','data' => ['type' => 'hidden','name' => 'order_id','value' => '']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('jet-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'hidden','name' => 'order_id','value' => '']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

                    <table class="table table-striped">
  <thead class="thead">
    <tr>
      <th scope="col">Entregable</th>
      <th > % Negociado</th>
      <th scope="col">Monto sin IVA</th>
      <th scope="col">IVA</th>
      <th scope="col">TOTAL</th>
      <th scope="col">Promesa de Pago </th>
      <th scope="col"># Dias </th>
      <th scope="col"># Semanas </th>

    </tr>
  </thead>
  <tbody>
  <?php $__currentLoopData = $payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


  <?php
{{$datetime1 = new DateTime($row->date);
  $datetime2 = new DateTime("2022-1-1");
  $dias = $datetime1->diff($datetime2)->format('%a');}}
?>
                            <tr class="text-center">
                                <td>  <?php echo e($row->concept); ?></td>
                                <td><?php echo e($row->percentage); ?> %</td>
                                <td><?php echo e($Coins -> symbol); ?> <?php echo e(number_format( $row->percentage * $Subtotal * 0.01)); ?></td>
                                <td><?php echo e($Coins -> symbol); ?> <?php echo e(number_format( $row->percentage * $Subtotal *0.0016)); ?></td>
                                <td><?php echo e($Coins -> symbol); ?> <?php echo e(number_format( $row->amount )); ?></td>
                                <td><?php echo e($row->date); ?></td>
                                <td><?php echo e($dias); ?></td>
                                <td><?php echo e((int)($dias / 7)); ?></td>
                      
                                
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <tr >
                            <td> </td>
    <th scope="row">TOTAL: </th>
      
      <td style="background-color:#A6ADBC"><?php echo e($Coins -> symbol); ?> <?php echo e(number_format($Subtotal)); ?></td>
      <td style="background-color:#A6ADBC"> <?php echo e($Coins -> symbol); ?> <?php echo e(number_format($Subtotal*0.16)); ?></td>
      <td style="background-color:#A6ADBC"> <?php echo e($Coins -> symbol); ?> <?php echo e(number_format($Subtotal*1.16)); ?></td>
    </tr>
   
  </tbody>
</table>
                
                </form>
            
                               
                                    

                
  <div class="row">
    <div class ="col"><input  class="btn btn-gray" type="button" name="imprimir" value="Imprimir" onclick="window.print();"> 
                </div>
    <div class ="col">
                <form action="<?php echo e(route('internal_orders.payment_edit', $InternalOrders->id)); ?>" method="POST">
                                            <?php echo csrf_field(); ?>                               
                                            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.input','data' => ['type' => 'hidden','name' => 'order_id','value' => ''.e($InternalOrders->id).'']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('jet-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'hidden','name' => 'order_id','value' => ''.e($InternalOrders->id).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                            <button  class="btn btn-green" type="submit" name="editar" >
                                                <i class="fas fa-edit"></i> &nbsp; Editar
                                            </button>
                                        </form>
                                        </div>
    <div class ="col"><?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('VER PEDIDOS')): ?>
                                        <a href="<?php echo e(route('internal_orders.show', $InternalOrders->id)); ?>">
                                            <i class="fa-solid fa-eye btn btn-blue ">Ver Detalles</i></span>
                                        </a>
                                        <?php endif; ?></div>
  </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

<?php if($actualized == 'SI'): ?>
<script type="text/javascript" src="<?php echo e(asset('vendor/mystylesjs/js/percentage_actualized.js')); ?>"></script>
<?php endif; ?>

<?php if($actualized == 'NO'): ?>
<script type="text/javascript" src="<?php echo e(asset('vendor/mystylesjs/js/percentage_incorrect.js')); ?>"></script>
<?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\admintyrsa2\tyrsaAdmin\resources\views/internal_orders/store_payment.blade.php ENDPATH**/ ?>