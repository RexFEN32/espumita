

<?php $__env->startSection('title', 'PEDIDO INTERNO'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1 class="font-bold"><i class="fa-solid fa-clipboard-check"></i>&nbsp; PEDIDO INTERNO</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-flex m-1 bg-gray-300 shadow-lg rounded-lg">
        <div class="row p-3 m-2 rounded-lg shadow-xl bg-white">
            <div class="row p-4">
                <div class="col-sm-12 text-center font-bold text-sm">
                    <table>
                        <tr>
                            <td rowspan="4">
                               <img src="<?php echo e(asset('img/logo/logo.svg')); ?>" alt="TYRSA">
                            </td>
                        </tr>
                        <tr>
                            <td class="text-lg" style="color: red"><?php echo e($CompanyProfiles->company); ?></td>
                        </tr>
                        <tr>
                            <td><?php echo e($CompanyProfiles->motto); ?></td>
                        </tr>
                        <tr class="text-xs">
                            <td>
                                <br>
                                Domicilio Fiscal:<br>
                                <?php echo e($CompanyProfiles->street.' '.$CompanyProfiles->outdoor.' '.$CompanyProfiles->intdoor.' '.$CompanyProfiles->suburb.' '.$CompanyProfiles->city.' '.$CompanyProfiles->state.' '.$CompanyProfiles->zip_code); ?><br>
                                R.F.C: <?php echo e($CompanyProfiles->rfc); ?> &nbsp; Tels: 01-52 <?php echo e($CompanyProfiles->telephone.', '.$CompanyProfiles->telephone2); ?> &nbsp; E-mail: <?php echo e($CompanyProfiles->email); ?> &nbsp; Web: <?php echo e($CompanyProfiles->website); ?>

                            </td>
                        </tr>
                    </table>
                </div>
            </div>
            <div class="row p-4">
                <div class="col-sm-9 col-xs-12 font-bold text-sm">
                    <table>
                        <tr>
                            <td>
                                Cliente: <?php echo e($Customers->id.' '. $Customers->customer); ?><br>
                                Dirección Fiscal: <?php echo e($Customers->customer_street.' '.$Customers->customer_outdoor.' '.$Customers->customer_intdoor.' '.$Customers->customer_suburb.' '.$Customers->customer_city.' '.$Customers->customer_state.' '.$Customers->customer_zip_code); ?><br>
                                R.F.C: <?php echo e($Customers->customer_rfc); ?> &nbsp; Tel: 01-52 <?php echo e($Customers->customer_telephone); ?> &nbsp; E-mail: <?php echo e($Customers->customer_email); ?> &nbsp; Web: <?php echo e($Customers->customer_website); ?>

                            </td>
                        </tr>
                    </table>
                </div>
                <div class="col-sm-3 col-xs-12 font-bold text-sm">
                    <table>
                        <tr>
                            <td class="card-body bg-white rounded-xl shadow-md text-center text-sm">
                                <span style="color: darkblue">PEDIDO No.:<br><br>
                                <?php echo e($InternalOrders->invoice); ?></span> 
                            </td>
                        </tr>
                    </table>
                </div>
            </div>
            <div class="row p-4">
                <div class="col-sm-12 font-bold text-sm">
                    <table>
                        <tr>
                            <td>Vendedor: <?php echo e($Sellers->id); ?></td>
                        </tr>
                        <tr>
                            <td>
                                <?php if($InternalOrders->shipment == 'Sí'): ?>
                                    Dirección Embarque: <?php echo e($CustomerShippingAddresses->customer_shipping_street.' '.$CustomerShippingAddresses->customer_shipping_outdoor.' '.$CustomerShippingAddresses->customer_shipping_intdoor.' '.$CustomerShippingAddresses->customer_shipping_suburb.' '.$CustomerShippingAddresses->customer_shipping_city.' '.$CustomerShippingAddresses->customer_shipping_state.' '.$CustomerShippingAddresses->customer_shipping_zip_code); ?><br>
                                <?php else: ?>
                                    Dirección Embarque:
                                <?php endif; ?>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                Fecha de Entrega del Equipo: <br><?php echo e(date('d-m-Y', strtotime($InternalOrders->date_delivery))); ?>

                            </td>
                            <td>
                                Fecha de Entrega Instalación: <br> <?php echo e(date('d-m-Y', strtotime($InternalOrders->instalation_date))); ?>

                            </td>
                            <td>
                                Condiciones de Pago: <br> <?php echo e($InternalOrders->payment_conditions); ?>

                            </td>
                        </tr>
                    </table>
                </div>
            </div>
            <div class="row p-4">
                <div class="col-sm-12 font-bold text-sm">
                    <table class="table table-striped text-xs font-medium">
                        <thead>
                            <tr class="text-center">
                                <th>Pda</th>
                                <th>Cant</th>
                                <th>Unidad</th>
                                <th>Familia</th>
                                <th>Clave</th>
                                <th>Descripción</th>
                                <th>P. U.</th>
                                <th>Importe</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $Items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="text-center">
                                <td><?php echo e($row->item); ?></td>
                                <td><?php echo e($row->amount); ?></td>
                                <td><?php echo e($row->unit); ?></td>
                                <td><?php echo e($row->family); ?></td>
                                <td><?php echo e($row->code); ?></td>
                                <td><?php echo e($row->description); ?></td>
                                <td class="text-right">$ <?php echo e(number_format($row->unit_price, 2)); ?></td>
                                <td class="text-right">$ <?php echo e(number_format($row->import, 2)); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="row p-4">
                <div class="col-sm-12 text-right">
                    <div class="form-group">
                        <span class="text-right font-bold text-md">Subtotal: $ <?php echo e(number_format($InternalOrders->subtotal,2)); ?></span>
                    </div>
                </div>
                <div class="col-sm-12 text-right">
                    <div class="form-group">
                        
                    </div>
                </div>
                <div class="col-sm-12 text-right">
                    <div class="form-group">
                        
                    </div>
                </div>
            </div>
            <div class="row p-4">
                <div class="col-sm-4 col-xs-12 text-center text-xs font-bold">
                    <table>
                        <tr>
                            <td>
                                <?php echo e($Sellers->seller_name); ?><br>
                              <!--  <?php echo e($Sellers->seller_email.' '.$Sellers->seller_mobile); ?>-->
                            </td>
                        </tr>
                        <tr>
                            <td>&nbsp;</td>
                        </tr>
                        <tr>
                            <td>&nbsp;</td>
                        </tr>
                        <tr>
                            <td>
                                <br>
                                <hr><br><br>

                                Elaboró
                            </td>
                        </tr>
                    </table>
                </div>
                <div class="col-sm-3 col-xs-12 text-center text-xs font-bold">
                    &nbsp;
                </div>
                <div class="col-sm-5 col-xs-12 text-center text-xs font-bold">
                     <?php $__currentLoopData = $requiredSignatures; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $firma): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
       

                        <ul>
                            <li>
                                <div class="row">


                                    <?php if($firma->status == 0): ?>
                                    <form action="<?php echo e(route('internal_orders.firmar')); ?>" method="POST" enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.input','data' => ['type' => 'hidden','name' => 'signature_id','value' => ''.e($firma->id).'']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('jet-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'hidden','name' => 'signature_id','value' => ''.e($firma->id).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                    <div class="col">
                                        <span class="text-xs uppercase">Firma: <?php echo e($firma->job); ?></span><br>
                                    </div>

                                    <div class="row">
                                        <div class="col">
                                            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.input','data' => ['type' => 'password','name' => 'key','class' => 'w-flex text-xs']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('jet-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'password','name' => 'key','class' => 'w-flex text-xs']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                        </div>
                                        <div class="col">
                                            <button class="btn btn-green">Firmar</button>
                                        </div>
                                    </div>
                                    </form>
                                    <?php else: ?>

                                    <span style="font-size: 17px"> <i style="color : green"  class="fa fa-check-circle" aria-hidden="true"></i> Autorizado por  <?php echo e($firma->job); ?> </span>
                                    <br><br><br><br>
                                    <?php endif; ?>
                                </div>
                            </li>
                        </ul>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <br>
                    <hr><br>
                    Autorizaciones
                </div>
            </div>
            <br> <br> 
            <?php if($InternalOrders->status == 'autorizado'): ?>
            <br><br><br><br><br>
                        <br><div>PEDIDO 100% AUTORIZADO</div><br>
                                         <!--
                                        <form action="<?php echo e(route('internal_orders.pagos', $row->id)); ?>" method="POST">
                                            <?php echo csrf_field(); ?>                               
                                            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.input','data' => ['type' => 'hidden','name' => 'order_id','value' => ''.e($InternalOrders->id).'']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('jet-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'hidden','name' => 'order_id','value' => ''.e($InternalOrders->id).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                            <button type="submit" class="btn btn-green">
                                                <i class="fa-solid fa-percent items-center fa-2x"></i> &nbsp; Porcentaje de Avances
                                            </button>
                                        </form>-->

                    <?php else: ?> 
                    <div>FALTAN AUTORIZACIONES</div>
                    <?php endif; ?>
                    <br><br><br>
                </div>
                    <input  class="btn btn-green" type="button" name="imprimir" value="Imprimir" id="printPageButton" onclick="window.print();"> 
                      
                    
  
        </div>
    </div>
    
            
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<style>
@media print {
  #printPageButton {
    display: none;
  }
}
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\admintyrsa2\tyrsaAdmin\resources\views/internal_orders/show.blade.php ENDPATH**/ ?>