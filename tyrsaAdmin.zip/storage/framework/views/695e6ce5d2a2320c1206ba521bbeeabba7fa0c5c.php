

<?php $__env->startSection('title', 'Cuentas por Cobrar'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1 class="font-bold"><i class="fa-solid fa-credit-card"></i>&nbsp; CUENTAS POR COBRAR</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-flex m-1 bg-gray-300 shadow-lg rounded-lg">
        <div class="row p-3 m-2 rounded-lg shadow-xl bg-white">
            <div class="row p-4">
              
                <div class="col-sm-12 text-center font-bold text-sm">
                
  
                <div class="float-left"><h1><span class="badge badge-danger"> $ <?php echo e($total); ?> <br> por cobrar <br> </span></h1></div>
                <br><br>
                <div class="container" style ="padding: 15px">
                <div class="btn-group" role="group"  aria-label="Basic example">
  <button type="button" class="btn btn-blue mb-2" onclick="Clientes()">Clientes</button>
  <button type="button" class="btn btn-blue mb-2" onclick="Ordenes()">Pedido</button>
  <button type="button"class="btn btn-blue mb-2"  onclick="Fechas()">Fecha</button>
</div></div>
<br> <br>
<div id = "ClientView">  
<div class ="justify-content-rigth"> </div>
<?php $__currentLoopData = $Customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<br>
<span class="float-left">
<button class="btn btn-blue" data-toggle="collapse" data-target="#collapseExample<?php echo e($row->id); ?>" aria-expanded="false" aria-controls="collapseExample">
    <i class="fa-solid fa-user fa-2x" ></i></span>
             &nbsp; &nbsp;
    <p><?php echo e($row->customer); ?></p></button></td>

    <?php
{{
  $pagos = $accounts->where('customer_id',$row->id);
  $pendientes = $pagos->where('status','por cobrar');
  $pagados = $pagos ->where('status','pagado');
  $total_pedidos=$Orders->where('customer_id',$row->id)->count();
}}
?>

    <div class="collapse" id="collapseExample<?php echo e($row->id); ?>">
      <table >
        <tbody>
          <tr>
            <td>
            Total de Pedidos &nbsp;
            </td>
            <td>
            Abonos pagados&nbsp;
            </td>
            <td>
            Porcentaje completado&nbsp;
            </td>
            <td>
            Saldo deudor&nbsp;
            </td>
          </tr>
          <tr>
            <td>
             <?php echo e($total_pedidos); ?>

            </td>
            <td>
            <?php echo e($pagados->count()); ?> / <?php echo e($pagos->count()); ?>

            </td>
            <td>
              <?php echo e($pagados->sum('percentage')); ?> %
            </td>
            <td style="color : red ">
            <?php echo e($row->symbol); ?> <?php echo e(number_format($pendientes ->sum('amount'))); ?>

            </td>
          </tr>
        </tbody>
      </table>

    <div class="column">
      <br>
        
        <table class="table-striped text-xs font-medium" >
            <thead class="thead">
               <tr style = "font-size : 14px ; padding : 15px">
               <th > Pedido</th>
               <th scope="col">concepto <br></th>
               <th scope="col">Cantidad</th>
               <th scope="col">Fechade pago</th>
               <th scope="col">Notas</th>
               <th scope="col">Estado</th>
               </tr>
               
            </thead>

            <tbody >
    <?php $__currentLoopData = $accounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pago): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($pago->customer_id == $row->id): ?>
                <tr style = "font-size : 14px; margin : 15px" >

                   <td>
                   <?php echo e($pago->invoice); ?>

                   <br>
                    </td>
                    <td>
                   <?php echo e($pago->concept); ?>

                    </td>
                    <td>
                    <?php echo e($row->symbol); ?><?php echo e(number_format($pago->amount)); ?>

                    </td>
                    <td>
                   <?php echo e($pago->date); ?>

                    </td>
                    <td>
                   <?php echo e($pago->nota); ?>

                    </td>
                    <td>
                    <?php {{
                      $fecha = new DateTime($pago->date);
                    }}?>

                    <?php if($pago->status == 'pagado'): ?>
                    <a href="<?php echo e(route('payments.pay_actualize',$pago->id)); ?>">
                        <button class="button"> <span class="badge badge-success">Pagado</span> </button>
                        </a> 
                      
                      <?php else: ?>
                      <?php if( now() > $fecha): ?>
                      <a href="<?php echo e(route('payments.pay_actualize',$pago->id)); ?>">
                      <button class="button"> <span class="badge badge-danger">atrasado</span> </button>
                      </a>  
                    <?php else: ?>
                      <a href="<?php echo e(route('payments.pay_actualize',$pago->id)); ?>">
                      <button class="button"> <span class="badge badge-info">por cobrar</span> </button>
                      </a>
                      <?php endif; ?>     
                    <?php endif; ?>           
                    </td>
                    
                   
                </tr>


<?php if($fecha >= now()): ?>
en tiempo
<?php endif; ?>

                <?php endif; ?>

                
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        
    </div>
  </div>
  <br>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

</div>
<div id = "OrderView">  
<?php $__currentLoopData = $Orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<br>
<button class="btn btn-blue" data-toggle="collapse" data-target="#collapseExample<?php echo e($row->id); ?>" aria-expanded="false" aria-controls="collapseExample">
    <i class="fa-solid fa-file fa-2x" ></i>
             &nbsp; &nbsp;
    <p><?php echo e($row->invoice); ?></p></button></td>
    <div class="collapse" id="collapseExample<?php echo e($row->id); ?>">

<?php
{{
  $pagos = $accounts->where('order_id',$row->id);
  $pendientes = $pagos->where('status','por cobrar');
  $pagados = $pagos ->where('status','pagado');
}}
?>
    <table>
        <tbody>
          <tr>
            <td>
              Monto total del pedido
            </td>
            <td>
              Abonos pagados
            </td>
            <td>
              Porcentaje completado
            </td>
            <td>
              Saldo deudor
            </td>
          </tr>
          <tr>
            <td>
             <?php echo e($row->symbol); ?> <?php echo e(number_format($row->subtotal*1.16)); ?>

            </td>
            <td>
            <?php echo e($pagados->count()); ?> / <?php echo e($pagos->count()); ?>

            </td>
            <td>
              <?php echo e($pagados->sum('percentage')); ?> %
            </td>
            <td style="color : red ">
            <?php echo e($row->symbol); ?> <?php echo e(number_format($pendientes ->sum('amount'))); ?>

            </td>
          </tr>
        </tbody>
      </table>
    <div class="column">
      <br>
        <table>
        <table class="table-striped text-xs font-medium">
            <thead class="thead">
               <tr style = "font-size : 14px; margin : 15px">
               <th > Cliente</th>
               <th scope="col">concepto</th>
               <th scope="col">Cantidad</th>
               <th scope="col">Fechade pago</th>
               <th scope="col">Notas</th>
               <th scope="col">Estado</th>
               </tr>
            </thead>

            <tbody>
    <?php $__currentLoopData = $accounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pago): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($pago->order_id == $row->id): ?>
                <tr  style = "font-size : 14px; margin : 15px">

                   <td>
                   <?php echo e($row->customer); ?>

                    </td>
                    <td>
                   <?php echo e($pago->concept); ?>

                    </td>
                    <td>
                   <?php echo e($row->symbol); ?><?php echo e(number_format($pago->amount)); ?>

                    </td>
                    <td>
                   <?php echo e($pago->date); ?>

                    </td>
                    <td>
                   <?php echo e($pago->nota); ?>

                    </td>
                    <td>
                    <?php {{
                      $fecha = new DateTime($pago->date);
                    }}?>

                    <?php if($pago->status == 'pagado'): ?>
                    <a href="<?php echo e(route('payments.pay_actualize',$pago->id)); ?>">
                        <button class="button"> <span class="badge badge-success">Pagado</span> </button>
                        </a> 
                      
                      <?php else: ?>
                      <?php if( now() > $fecha): ?>
                      <a href="<?php echo e(route('payments.pay_actualize',$pago->id)); ?>">
                      <button class="button"> <span class="badge badge-danger">atrasado</span> </button>
                      </a>  
                    <?php else: ?>
                      <a href="<?php echo e(route('payments.pay_actualize',$pago->id)); ?>">
                      <button class="button"> <span class="badge badge-info">por cobrar</span> </button>
                      </a>
                      <?php endif; ?>     
                    <?php endif; ?>          
                                
                    </td>
                </tr>

                <?php endif; ?>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        
    </div>
  </div>
  <br>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</div>

<br><br><br><br>
<div id = "DateView">  
  <div style ="flex-direction: row">  
    <p>Fehca Inicial</p>  <input type="date" style="width : 20%">&nbsp;&nbsp;&nbsp;
    <h1>Fehca Final</h1>  <input type="date" style="width : 20%">&nbsp;&nbsp;&nbsp;
  </div>
  <br>
        <div class="col-sm-12 table-responsive">
                  
                <table class="table tablepayments table-striped text-xs font-medium">
  <thead class="thead">
    <tr>
      <th scope="col">Cliente</th>
      <th > Pedido</th>
      <th scope="col">concepto</th>
      <th scope="col">Cantidad</th>
      <th scope="col">Fechade pago</th>
      <th scope="col">Notas</th>
      <th scope="col">Estado</th>
    </tr>
  </thead>
  <tbody>
  <?php $__currentLoopData = $accounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  
<?php if($row->status=="por cobrar"): ?>
                            <tr class="text-center">
                            <?php
{{$order = DB::table('payments')
    ->join('internal_orders', 'payments.order_id', '=', 'internal_orders.id')
    ->join('customers','customers.id','=','internal_orders.customer_id')
    ->select('payments.*','customers.customer','internal_orders.invoice')
    ->where('payments.order_id', $row->order_id)
    ->first();
    $coin = DB::table('internal_orders')
    ->join('coins', 'coins.id', '=', 'internal_orders.coin_id')
    ->where('internal_orders.id', $row->order_id)
    ->first();
    $fecha = new DateTime($row->date);
    $hoy = new DateTime("2022-11-7");
  }}
?>
                                <td> <p><?php echo e($order->customer); ?></p></td>
                                <td> <?php echo e($order->invoice); ?></td>
                                <td> <?php echo e($row->concept); ?></td>
                                <td> <?php echo e($coin->symbol); ?><?php echo e(number_format($row->amount)); ?></td>
                                <td><?php echo e($row->date); ?> </td>
                               
                                <td><?php echo e($row->nota); ?></td>
                                <td>

                                <?php if($fecha < now()): ?>
                                <a href="<?php echo e(route('payments.pay_actualize',$row->id)); ?>">
                                  <button class="button"> <span class="badge badge-danger">Atrasado</span> </button>
                                  </a>  
                                  <?php else: ?>
                                  <a href="<?php echo e(route('payments.pay_actualize',$row->id)); ?>">
                                    <button class="button"> <span class="badge badge-info">por cobrar</span> </button>
                                     </a>     
                                  <?php endif; ?>
                                 
                               </td>
                                
                            </tr>
<?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  
  </tbody>
</table>
            </div>
            </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

<script type="text/javascript" src="<?php echo e(asset('vendor/mystylesjs/js/tablecatalogopayments.js')); ?>"></script>
<script>
  document.getElementById("ClientView").hidden="hidden";
  document.getElementById("OrderView").hidden="hidden";

  function Clientes(){
    document.getElementById("ClientView").hidden="";
    document.getElementById("OrderView").hidden="hidden";
    document.getElementById("DateView").hidden="hidden";
  }
  
  function Ordenes(){
    document.getElementById("ClientView").hidden="hidden";
    document.getElementById("DateView").hidden="hidden";
    document.getElementById("OrderView").hidden="";
  }

  function Fechas(){
    document.getElementById("ClientView").hidden="hidden";
    document.getElementById("DateView").hidden="";
    document.getElementById("OrderView").hidden="hidden";
  }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\admintyrsa2\tyrsaAdmin\resources\views/accounting/cuentas_cobrar.blade.php ENDPATH**/ ?>