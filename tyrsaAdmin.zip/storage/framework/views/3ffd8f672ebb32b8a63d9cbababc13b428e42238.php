

<?php $__env->startSection('title', 'Cuentas por Cobrar'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1 class="font-bold"><i class="fa-solid fa-credit-card"></i>&nbsp; CUENTAS POR COBRAR</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-flex m-1 bg-gray-300 shadow-lg rounded-lg">
        <div class="row p-3 m-2 rounded-lg shadow-xl bg-white">
            <div class="row p-4">
                <div class="col-sm-12 text-center font-bold text-sm">
                <table>
                        <tr>
                            <td rowspan="4">
                               <img src="<?php echo e(asset('img/logo/logo.svg')); ?>" alt="TYRSA">
                            </td>
                            <td>
                                <h1 style="font-size : 30px; color: red;">Cancelacion del pago NO. <?php echo e($pay->id); ?></h1>
                            </td>
                        </tr>
                        <tr>
                            
                        </tr>
</table>

            <div class="col-sm-12 text-center font-bold text-sm">

            <table class="table table-striped">
                <tbody>
                    <tr>
                        <td style="background-color:#A6ADBC"> Cliente</td>
                        <td>Cliente de Prueba 01</td>
                    </tr>
                    <tr>
                        <td style="background-color:#A6ADBC"> Pedido </td>
                        <td><?php echo e($order->invoice); ?></td>
                    </tr>
                    <tr>
                        <td style="background-color:#A6ADBC"> Cantidad del pago</td>
                        <td> $ <?php echo e(number_format($pay -> amount)); ?></td>
                    </tr>
                    <tr>
                        <td>Concepto</td>
                        <td><?php echo e($pay ->concept); ?></td>
                    </tr>
                </tbody>
            </table>
            </div>
            <div style="color : red">
            Estas a punto de cancelar el pago con id <?php echo e($pay->id); ?> asociado al concepto <?php echo e($pay->concept); ?>

            de la orden <?php echo e($order->invoice); ?> del cliente <?php echo e($order->customer); ?>, es nescesaria una autorizacion.
            <i class="fa-solid fa-exclamation-triangle fa-2xl" ></i>
            </div>
            <br><br><br>
            <div>
            <form action="<?php echo e(route('accounting.invalidar')); ?>" method="POST" enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.input','data' => ['type' => 'hidden','name' => 'pay_id','value' => ''.e($pay->id).'']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('jet-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'hidden','name' => 'pay_id','value' => ''.e($pay->id).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                    <div class="col">
                                        <span class="text-xs uppercase">Firma: </span><br>
                                    </div>

                                    <div class="row">
                                        <div class="col">
                                            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.input','data' => ['type' => 'password','name' => 'key','class' => 'w-flex text-xs']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('jet-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'password','name' => 'key','class' => 'w-flex text-xs']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                        </div>
                                        <div class="col">
                                            <button class="btn btn-red">Invalidar</button>
                                        </div>
                                    </div>
                                    </form>
                
            </div>
         <br><br>
         
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>

    
<?php $__env->stopSection(); ?>


<?php $__env->startSection('js'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\admintyrsa2\tyrsaAdmin\resources\views/accounting/pay_cancel.blade.php ENDPATH**/ ?>