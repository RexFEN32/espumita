<?php

namespace App\Http\Controllers;

use App\Models\tesmod;
use App\Http\Requests\StoretesmodRequest;
use App\Http\Requests\UpdatetesmodRequest;

class TesmodController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \App\Http\Requests\StoretesmodRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function store(StoretesmodRequest $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\tesmod  $tesmod
     * @return \Illuminate\Http\Response
     */
    public function show(tesmod $tesmod)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\tesmod  $tesmod
     * @return \Illuminate\Http\Response
     */
    public function edit(tesmod $tesmod)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \App\Http\Requests\UpdatetesmodRequest  $request
     * @param  \App\Models\tesmod  $tesmod
     * @return \Illuminate\Http\Response
     */
    public function update(UpdatetesmodRequest $request, tesmod $tesmod)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\tesmod  $tesmod
     * @return \Illuminate\Http\Response
     */
    public function destroy(tesmod $tesmod)
    {
        //
    }
}
